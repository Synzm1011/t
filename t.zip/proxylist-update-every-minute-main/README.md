
```mermaid
pie title 46665 Proxies in list
    "HTTP" : 25327
    "HTTPS": 7163
    "SOCKS" : 19556
```

### Some Info
#### Average Timeout

- mixed: 3.1s
- http: 1.5s
- https: 8.5s
- socks: 6.2s